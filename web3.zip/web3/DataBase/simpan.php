<?php
include("koneksi.php");
if(isset($_POST['proses']) && $_POST['proses']!==""){
	//Variable POST
	$NIP = $_POST['txtnip'];
	$NAMA = $_POST['txtnama'];
	$GAJI = $_POST['txtgaji'];
	
	
	$query = "insert into tblgaji
				(Nip,Nama,Gaji) 
			value
				('".$NIP."','".$NAMA."','".$GAJI."')";
	$execute = mysql_query($query,$koneksi);
	if($execute){
		echo "<script>
				alert('Data Berhasil Di Tambah.');
				location.href='tampil.php';
			</script>";
	}
}
?>
