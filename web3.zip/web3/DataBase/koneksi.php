<?php
$HOST = "localhost";
$USER = "root";
$PASSWORD = "admin";
$DATABASE = "dbgaji";
//Proses Koneksi//
$koneksi = mysql_connect($HOST,$USER,$PASSWORD);
$database = mysql_select_db($DATABASE,$koneksi);
?>
