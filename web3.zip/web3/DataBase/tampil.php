<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>Document</title>
<link href="../css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="../css/tampil.css">
</head>
<body>
	
<?php
include("koneksi.php"); //koneksi ke database
$query = "select * from tblgaji";
$execute = mysql_query($query,$koneksi); //Memasukan query
if(mysql_num_rows($execute)>0){//Melakukan Pengecekan apakah data ada.

	echo "<div class='container'>";
	echo "<table class='table table-bordered'>
			<tr>
				<th>No.</th>
				<th>Nip</th>
				<th>Nama</th>
				<th>Gaji</th>
				<th>Aksi</th>
				</tr>";
	echo "</div>";
	$I= 1;
	while($row = mysql_fetch_array($execute)){
		$ID = $row['Id'];
		$NIP = $row['Nip'];
		$NAMA = $row['Nama'];
		$GAJI = $row['Gaji'];
				
		echo "<tr>
				<td>".$I."</td>
				<td>".$NIP."</td>
				<td>".$NAMA."</td>
				<td>".$GAJI."</td>
				<td><a href=\"edit.php?id=$ID\">Edit<a> | <a href=\"delete.php?id=$ID\" onClick=\"return confirm('Hapus?');\">Delete</a></td>
			</tr>";
		$I++;
	}
	echo "</table>";
}else{
	echo "Data Mahasiswa Tidak Ada.";
}

echo "<a href='input.html'>Input Lagi !</a>";
?>

</body>
<script src="../js/bootstrap.min.js"></script>