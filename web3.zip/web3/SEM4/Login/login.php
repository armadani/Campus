<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>login Veni Alpionita</title>
<link rel="stylesheet" href="style.css" type="text/css" />
</head>

<body>
<div class="container">
<h1>Veni</h1>
<div class="login-body">
<div class="top-login">
<div class="title">
Login form</div>
<div class="line-1"></div>
<div class="line-2"></div>
<div class="line-3"></div>
<div class="line-11"></div>
<div class="line-22"></div>
<div class="line-33"></div>
<div class="line-111"></div>
<div class="line-222"></div>
<div class="line-333"></div>
</div>

<div class="character-circel">
<div class="character-body">
<div class="head"></div>
<div class="hair1"></div>
<div class="hair2"></div>
</div>
</div>

<div class="character-bacground"></div>
<div class="character-bacground2"></div>
<div class="character-bacground3"></div>
<div class="character-circle1"></div>
<div class="character-circle2"></div>

<div class="login-box">
<div class="line1"></div>
<div class="line2"></div>
<div class="morab31"></div>
<div class="morab32"></div>
<div class="morab33"></div>
<div class="morab34"></div>

<input type="text" name="username" placeholder="username...">
<input type="password" name="password" placeholder="password...">
<button class="button" type="submit" name="proseslogin" value="proseslogin"> sign in </button>

<div class="last-info">

<div class="one">

remember me
<input type="checkbox" id="thing">
<label for="thing"></label>

</div>

<div class="two">

<a href="#">create Account</a>

</div>

<div class="three">

<a href="#">Forget password ?</a>

</div>
</div>
</div>

<div class="down-login">

</div>
</div>
</div>












</body>
</html>

