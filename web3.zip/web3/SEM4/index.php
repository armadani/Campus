<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Santi Atika</title>
<link rel="stylesheet" href="style/style.css" type="text/css" />
<script type="text/javascript" src="jquery-1.2.6.min.js"></script>
<link rel="stylesheet" type="text/css" href="jquery-ui-1.11.2/jquery-ui.css" >

<script type="text/javascript">

	function slideSwitch(){
		var $active = $('#slideshow IMG.active');
		if ($active.length == 0) $active = $('#slideshow IMG:last');
		var $next = $active.next().length ? $active.next()
		:$('#slideshow IMG:first');
		$active.addClass('last-active');

		$next.css({opacity:0.0})
		.addClass('active')
		.animate({opacity:1.0}, 1000, function() { 
		$active.removeClass('active last-active');
	});
	}

	$(function() {
		setInterval("slideSwitch()", 2000);
	});
	</script>
	<style type="text/css">
	#slideshow IMG.active{
		z-index: 10;
		opacity: 1.0;
	}
	</style>
</head>

<body>

<div id="wrapper">
<div id="header">
<h4 align="center">STMIK TRIGUNA DHARMA</h4>
<h4 align="center">MENERIMA MAHASISWA/I BARU 2017/2018</h4>
</div>

<ul id="menu">
	<li><a href="#">HOME</a></li>
	<li><a href="#">BERITA</a>
		<ul>
		<li><a href="#">Selebritis</a></li>
		<li><a href="#">Ekonomi</a></li>
		<li><a href="#">Tutorial</a></li>
		<li><a href="#">Sport</a></li>
		<li><a href="#">Iklan</a></li>
		</ul>
	</li>
		<li><a href="#">AGENDA</a></li>
		<div id="login"><a href="#">ADMIN</a></div>
	</ul>
<div id="isi">
	<div id="kiri">
		<div id="judul">BREAKING NEWS</div>
		<div id="bingkai"></div>
	</div>
	<div id="kanan">
		<div id="cari"><input type="submit" value="CARI" name="btncari"/> <input type="text" name="txtcari" size"15"/></div>
		<div id="slideshow">
		<img src="Image/1.jpg" />
		<img src="Image/2.jpg" />
		<img src="Image/3.jpg" />
		<img src="Image/4.jpg" />
		<img src="Image/5.jpg" />
		</div>
		
		<div id="clock">
<script type="text/javascript">
		<!--
		function startTime() {
		var today=new Date(),
		curr_hour=today.getHours(),
		curr_min=today.getMinutes(),
		curr_sec=today.getSeconds();
		curr_hour=checkTime(curr_hour);
		curr_min=checkTime(curr_min);
		curr_sec=checkTime(curr_sec);
		document.getElementById('clock').innerHTML=curr_hour+":"+curr_min+":"+curr_sec;
		}
		function checkTime(i) {
		if(i<10){
		i="0" + i;
		}
		return i;
		}
		setInterval(startTime,500);
		//-->
		</script>
		
	</div>
	
				<?php
			if(!isset($_SESSION['user'])){
				?>
				<?php }else{
					?>
	
<div id="berita"><a href="">Isi Berita</a></div>
<div id="keluar"><a href="">Log Out</a></div>
		<?php
			}
		?>
	<div id="date"></div>
	</div>
</div>
<div id="footer">Copy Right <a href="#">@ Santi Atika</a> 2018</div>


</body>
</html>

<script src="jquery-ui-1.11.2/external/jquery/jquery.js"></script>
<script src="jquery-ui-1.11.2/jquery-ui.js"></script>
<script>
$ ( "#date" ) .datepicker({

});
</script>
