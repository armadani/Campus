<?php
  session_start();
  include("config/koneksi.php");
?>

<html>
    <head>
    <title>Login Admin</title>
<link href="../js/jquery-ui-1.11.2/jquery-ui.css" rel="stylesheet" />
<link href="../css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="../css/adminstyle.css" />
<script type="text/JavaScript"></script>
    </head>
<body>
<div class="jumbotron">
<form action="../files/menu/login/index.php" method="post">
    <div class="container">

        <img src="../img/logo.png" class="logo">
        <div class="box3">
            <form action="../menu/login/index.php" method="post">
            
                        <span>Username</span>
                        <input class="form-control col-md-12 username" type="text" name="username" required placeholder="Masukkan username">
                            <br>
                        <span>Password</span>
                        <input class="form-control col-md-12 password" type="password" name="password" required placeholder="Masukkan password">
                            <br>
                <button type="reset" value="Cancel" name="prosescancel" class="btn btn-warning">Reset</button>
                <button type="submit" value="Login" name="proseslogin" class="btn btn-success" style="margin-left:10px;">Kirim</button>
            </form>
        </div>        
    </div>
</div>



<!-- <div id="loginform">
    <form action="menu/login/index.php" method="post">
	  <span>::Login Admin::</span>
	   <br>
	    <span>Username</span>
        <input type="text" name="username" required>
        <br>
	    <span>Password</span>
        <br>
	    <input type="password" name="password" required>
	       <input type="submit" value="Login" name="proseslogin">
	       <input type="reset" value="Cancel" name="prosescancel">
    </form>
          </div> -->
          <!-- close form login-->		
</body>
    <script src="../js/bootstrap.min.js"></script>
</html>
