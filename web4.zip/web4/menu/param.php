<?php
    if($_GET['menu']=="berita"){
    include("menu/berita/index.php");
    }elseif($_GET['menu']==""){
    include("menu/index.php");
    }
?>