<?php
include("config/koneksi.php");
if(isset($_GET['act']) && $_GET['act']=="tambahberita"){//Jika Penambahan
	$JUDUL = mysql_real_escape_string($_POST['judul']);
	$ISIBERITA = mysql_real_escape_string($_POST['isi_berita']);
	
	/**Set Variable Image**/
	$IMAGENAME = $_FILES['gambar']['name'];
	$IMAGETEMP = $_FILES['gambar']['tmp_name'];
	$IMAGEGETNAME = substr($IMAGETEMP,-8,4).$IMAGENAME;
	$MOVE = move_uploaded_file($IMAGETEMP,"Image/".$IMAGEGETNAME);

	$query = "insert into tbl_berita
				(judul, isi_berita, gambar)
			values
	('".$JUDUL."', '".$ISIBERITA."','".$IMAGEGETNAME."')";
	$execute = mysql_query($query,$koneksi);
	if($execute){
		echo "<script>
				alert('Data Berhasil Di Tambah.');
			location.href='index.php?menu=berita';
		</script>";
	}
}
?>