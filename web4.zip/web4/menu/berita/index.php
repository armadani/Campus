<?php include("param.php");?>
<style>
	
</style>

	<form action="index.php?menu=berita&amp;act=tambahberita" method="post" enctype="multipart/form-data">
		
		<table>
			<tr>
				<td>Judul</td>
				<td>:</td>
				<td align="left"><input type="text" name="judul" required></td>
			</tr>
			<tr>
				<td>Isi Berita</td>
				<td>:</td>
				<td><textarea name="isiberita" required cols="60" rows="10"></textarea></td>
			</tr>
			<tr>
				<td>Gambar</td>
				<td>:</td>
				<td><input type="file" name="gambar"></td>
			</tr>
			<tr>
				<td colspan="3"><input type="submit" name="inputberita" value="Proses"></td>
			</tr>
		</table>
	</form>