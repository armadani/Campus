<?php
include("../../config/koneksi.php");

$id=abs(intval($_GET['id']));
$query=mysql_query("SELECT * FROM tbl_berita WHERE id='$id' LIMIT 1");
    while($data=mysql_fetch_array($query)) {
        echo "<h2>".$data['judul']."</h2>";
        echo "<p>".$data['isi_berita']."</p>";
    }
?>