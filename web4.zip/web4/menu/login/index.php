<?php
session_start();
include("../../config/koneksi.php");

if(isset($_POST['proseslogin']) && $_POST['proseslogin']!==""){
	$USERNAME = mysql_real_escape_string($_POST['username']);
	$PASSWORD = mysql_real_escape_string($_POST['password']);
	
	$query = "select * from tbl_login where 
			username ='".$USERNAME."' and 
			password = '".$PASSWORD."'";
			
	$execute = mysql_query($query,$koneksi);
	
	if(mysql_num_rows($execute)>0){
		$row = mysql_fetch_array($execute);
		$userforsession = $row['username'];
		$_SESSION['user'] = $userforsession;
		
		echo "<script>
				alert('Selamat Datang');
				location.href='../../index.php';
			</script>";
	
	}else{
		echo "<script>
				alert('Login Gagal');
				location.href='../../index.php';
			</script>";
	}
}
?>
