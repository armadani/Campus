<style>
    .boxberita{
        margin: auto;
        background: gray;
        padding: 8px;
        border-radius: 5px;
        margin-bottom: 5px;
        width: 550px;
    }    

        .boxberita .gambar img{
            width: 100px;
            height: 100px;
            float: left;
            margin-right: 5px;
            border: 1px solid white;
        }
        
        .boxberita .judulberita{
            font-weight: bold;
            font-size: 16px;
            float: left;
            color: lightgreen;
        }
        
        .boxberita .isiberita {
            font-size: 12px;
            color: white;
        }

        .boxberita .lihatberita {
            font-size: 12px;
            font-weight: bold;
        }
</style>

    <?php
		$query = mysql_query("select * from tbl_berita order by id DESC limit 3");
		if(mysql_num_rows($query)>0){
			while($row = mysql_fetch_array($query)){
				/*SET VARIABLE*/
				$JUDUL = $row['judul'];
				$GAMBAR = $row['gambar'];
				$ISIBERITA = substr($row['isi_berita'],0,200);
				$PENGAMBILANSPASI = strrpos($ISIBERITA," ");
				$ISIBERITASHOW = substr($ISIBERITA,0,$PENGAMBILANSPASI)."....";				
				
				echo "<div class=\"boxberita\">
						<div class=\"gambar\"><img src=\"Image/$GAMBAR\" /></div>
						<div class=\"judulberita\">$JUDUL</div>
						<br /> <br />
						<div class=\"isiberita\">$ISIBERITASHOW</div>
						<div class=\"lihatberita\"><a href=menu/berita/artikel.php?id=".$row['id'].">More</div>
						<div class=\"clearfix\"></div>
					</div>";
					
			}
		}else{
			echo "Data Kosong";
		}
    ?>