<?php
$HOST="localhost";
$USER="root";
$PASSWORD="admin";
$DATABASE="db_Ade";
//proses koneksi//
$koneksi= mysql_connect($HOST,$USER,$PASSWORD);
$database= mysql_select_db($DATABASE,$koneksi);
?>
