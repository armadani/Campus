<?php
    session_start();
    include("config/koneksi.php")
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <!-- jQuery -->
    <!-- <script type="text/javascript" src="jquery-3.3.1.min.js"></script> -->
    <script type="text/javascript" src="jquery-1.2.6.min.js"></script>
    
    <!-- jQuery ui -->
    <link rel="stylesheet" type="text/css" href="jquery-ui-1.11.2/jquery-ui.css" >
    <!-- <link rel="stylesheet" type="text/css" href="jquery-ui-1.12.1/jquery-ui.min.css"> -->

    <!-- Boostrap -->
    <link href="style/bootstrap/bootstrap.min.css" rel="stylesheet"> <!-- bootstrap 4.1.1 -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB" crossorigin="anonymous">
    
    <link rel="stylesheet" type="text/css" href="style/fileindex2.css" />
   
    <title>Adeputra</title>

    <!-- JavaScript --> 
    <script type="text/javascript">

	function slideSwitch(){
		var $active = $('#slideshow IMG.active');
		if ($active.length == 0) $active = $('#slideshow IMG:last');
		var $next = $active.next().length ? $active.next()
		:$('#slideshow IMG:first');
		$active.addClass('last-active');

		$next.css({opacity:0.0})
		.addClass('active')
		.animate({opacity:1.0}, 1000, function() { 
		$active.removeClass('active last-active');
	});
	}

	$(function() {
		setInterval("slideSwitch()", 2000);
	});
    </script>
    <!-- CLOSE JS -->
    
    <style type="text/css">
	#slideshow IMG.active{
		z-index: 10;
		opacity: 1.0;
    }
    </style>

</head>
<body>
    <nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand nav-text" href="#">Adeputra Armadani</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav">
                <a class="nav-item nav-link active" href="#">Home <span class="sr-only">(current)</span></a>
                <a class="nav-item nav-link" href="htp://www.localhost/portfolio">Portfolio</a>
                <a class="nav-item nav-link" href="#">Gallery</a>
                <a class="nav-item nav-link disabled" href="#">Contact</a>
                </div>
            </div>
            <form class="form-inline my-2 my-lg-0">
                    <input class="form-control mr-sm-2" type="search" placeholder="Cari" aria-label="Search">
                    <button class="btn btn-outline-success my-2 my-sm-0" name="btncari" type="submit">Search</button>
                </form>
        </div>
    </nav>

    <!-- <div class="top-bar cf">
        <div class="comin">
            <ul>
                <li><a href="">Register</a></li>  
                <li><a href="">Login</a></li>
            </ul>
        </div>tutup comin -->
    </div> 

    <div id="wrapper">
        <div id="header">
            <div class="bungkus">
                <img class="gambar" src="img/logo.png" alt="logo">
            </div> <!-- tutup class bungkus -->

            <h4 align="center" class="h4">STMIK TRIGUNA DHARMA</h4>
            <h4 align="center" class="h4">MENERIMA MAHASISWA/I BARU 2017/2018</h4>
        </div> <!-- tutup header -->
        <ul id="menu">
            <li><a href="#">HOME</a></li>
            <li><a href="#">BERITA</a>
                <ul>
                    <li><a href="#">Selebritis</a></li>
                    <li><a href="#">Ekonomi</a></li>
                    <li><a href="#">Tutorial</a></li>
                    <li><a href="#">Sport</a></li>
                    <li><a href="#">Iklan</a></li>
                </ul>
            </li>
            <li><a href="#">AGENDA</a></li>
            <div id="login"><a href="login/login.php">ADMIN</a></div>
        </ul>
        <div id="isi">
            <div id="kiri">
                <div id="judul">BREAKING NEWS</div>
                <div id="bingkai">

                 <?php
                    include("menu/param.php");
                ?>

                </div><!-- tutup id bingkai -->
            </div> <!-- tutup kiri-->
            
            
               

            <div id="kanan">
                <!-- <div id="cari">
                    <table style="margin-top:10px;margin-left:10px;">
                        <tr>
                            <td><input type="submit" value="CARI" name="btncari" class="btn btn-warning"></td>
                            <td><input type="text" placeholder="cari" class="form-control col-md-12"></td>
                        </tr>
                    </table>
                </div> -->

                    <div id="slideshow">
                        <img src="img/1.jpeg" />
                        <img src="img/2.jpeg" />
                        <img src="img/3.jpeg" />
                        <img src="img/4.jpeg" />
                        <img src="img/5.jpeg" />
                    </div> <!-- close slideshow -->

                    <div id="clock">
                        <script type="text/javascript">
                                <!--
                                function startTime() {
                                var today=new Date(),
                                curr_hour=today.getHours(),
                                curr_min=today.getMinutes(),
                                curr_sec=today.getSeconds();
                                curr_hour=checkTime(curr_hour);
                                curr_min=checkTime(curr_min);
                                curr_sec=checkTime(curr_sec);
                                document.getElementById('clock').innerHTML=curr_hour+":"+curr_min+":"+curr_sec;
                                }
                                function checkTime(i) {
                                if(i<10){
                                i="0" + i;
                                }
                                return i;
                                }
                                setInterval(startTime,500);
                                //-->
                                </script>
                    </div> <!-- close clock -->

    <?php
		if(!isset($_SESSION['user'])){
	?>
	<?php }else{
	?>
    
    <!-- <div id="berita" ><a href="">Isi Berita</a></div> -->
    <div class="btn btn-outline-info btn-kanan" ><a href="index.php?menu=berita">Isi Berita</a></div>
    <!-- <div id="keluar"><a href="menu/login/logout.php">Log Out</a></div> -->
    <div class="btn btn-outline-danger btn-kanan"><a href="menu/login/logout.php">Log Out</a></div>
		<?php
			}
		?>
    <div id="date"></div>
            </div><!--tutup kanan-->
        </div><!-- tutup isi -->
        <!-- </div> tutup menu STING  -->
        
        <!-- <div class="jumbotron">
            <form>
                <div class="form-group">
                    <label for="exampleInputEmail1">Email address</label>
                    <input type="email" class="form-control col-4" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
                    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">Comment</label>
                    <input type="textarea" class="form-control col-4" id="exampleInputPassword1" placeholder="Password">
                </div>
                <button type="submit" class="btn btn-primary">Kirim</button>
            </form>
        </div> -->

        
        <!-- <div class="footer"><p>Copy right <a href="#">@Adeputra</a> 2018</p></div> -->
        <div class="footer2"><p>Copy right <a href="#">Adeputra Armadani</a> 2018 .all right reversed</p></div>
    </div> <!-- close wrapper  -->



<!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="jquery-3.3.1.slim.min.js"></script>

    <!-- Popper.js -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="popper.min.js"></script>

    <!-- Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T" crossorigin="anonymous"></script>
    <script src="style/bootstrap/bootstrap.min.js"></script>
    
</body>
</html>
<script src="jquery-ui-1.11.2/external/jquery/jquery.js"></script>
<script src="jquery-ui-1.12.1/external/jquery/jquery.js"></script> <!-- alternative -->

<script src="jquery-ui-1.11.2/jquery-ui.js"></script>
<script src="jquery-ui-1.12.1/jquery-ui.js"></script> <!-- alternative -->
<script>
    $ ( "#date" ) .datepicker({

    });
</script>
