<?php
$HOST = "localhost";
$USER = "root";
$PASSWORD = "";
$DATABASE = "dbmhs1";
//Proses Koneksi//
$koneksi = mysql_connect($HOST,$USER,$PASSWORD);
$database = mysql_select_db($DATABASE,$koneksi);
?>
