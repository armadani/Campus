<?php
include("koneksi.php");
if(isset($_POST['proses']) && $_POST['proses']!==""){
	//Variable POST
	$NIM = $_POST['txtnim'];
	$NAMA = $_POST['txtnama'];
	$NILAI = $_POST['txtnilai'];
	
	
	$query = "insert into tblmhs
				(Nim,Nama,Nilai) 
			value
				('".$NIM."','".$NAMA."','".$NILAI."')";
	$execute = mysql_query($query,$koneksi);
	if($execute){
		echo "<script>
				alert('Data Berhasil Di Tambah.');
				location.href='tampil.php';
			</script>";
	}
}
?>
