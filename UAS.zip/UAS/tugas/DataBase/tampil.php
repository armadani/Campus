<?php
include("koneksi.php"); //koneksi ke database
$query = "select * from tblmhs";
$execute = mysql_query($query,$koneksi); //Memasukan query
if(mysql_num_rows($execute)>0){//Melakukan Pengecekan apakah data ada.
	echo "<table border=\"1\">
			<tr>
				<th>No.</th>
				<th>Nim</th>
				<th>Nama</th>
				<th>Nilai</th>
				<th>Aksi</th>
				</tr>";
	$I= 1;
	while($row = mysql_fetch_array($execute)){
		$ID = $row['No'];
		$NIM = $row['Nim'];
		$NAMA = $row['Nama'];
		$NILAI = $row['Nilai'];
				
		echo "<tr>
				<td>".$I."</td>
				<td>".$NIM."</td>
				<td>".$NAMA."</td>
				<td>".$NILAI."</td>
				<td><a href=\"edit.php?id=$ID\">Edit<a> | <a href=\"delete.php?id=$ID\" onClick=\"return confirm('Hapus?');\">Delete</a></td>
					</tr>";
		$I++;
	}
	echo "</table>";
}else{
	echo "Data Mahasiswa Tidak Ada.";
}

echo "<a href='input.html'>Input Lagi !</a>";
?>
