<?php
include("koneksi.php");
if(isset($_GET['id']) && $_GET['id']!==""){ 
	$IDUPDATE = $_GET['id'];
	$query = "select * from tblmhs where No= '".$IDUPDATE."'";
	$execute = mysql_query($query,$koneksi);
	if(mysql_num_rows($execute)>0){
		$row = mysql_fetch_array($execute);
		$NIM = $row['Nim'];
		$NAMA = $row['Nama'];
		$NILAI = $row['Nilai'];
				
	}
}

if(isset($_POST['edit']) && $_POST['edit']!==""){
	$ID = $_GET['id'];
	$NIM = $_POST['Nim'];
	$NAMA = $_POST['Nama'];
	$NILAI = $_POST['Nilai'];
	$query = "update tblmhs set
				Nim = '".$NIM."',
				Nama = '".$NAMA."',
				Nilai = '".$NILAI."'
				where No ='".$ID."'";

$execute = mysql_query($query,$koneksi);
	if($execute){
		echo "<script>
				alert('Data Berhasil Di Ubah.');
				location.href='tampil.php';
			</script>";
	}
}
?>


<html>
<head>

<title>Form Edit Input Mahasiswa</title>
</head>
<body>
	<form action="" method="POST">
	<table border="1">
    	<tr>
		<td>Nim </td>
		<td>:<input type="text" name="Nim" value="<?php echo $NIM;?>"></td>
	</tr><br>
    	
	<tr>
		<td>Nama </td>
		<td>:<input type="text" name="Nama" value="<?php echo $NAMA;?>"></td>
	</tr><br>
    
	<tr>
		<td>Nilai </td>
		<td>:<input type="text" name="Nilai" value="<?php echo $NILAI;?>"></td>
    	<tr><br>
		<td><input type="submit" name="edit" value="EDIT"></td>
		<td><a href="tampil.php">Batal</a></td>
	</tr><br>
	</table>   
 </form>
</body>
</html>

