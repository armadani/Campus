<?php
include("koneksi.php");
if(isset($_GET['id']) && $_GET['id']!==""){
	$ID = $_GET['id'];
	$query = "delete from tblmhs where No='".$ID."'";
	$execute = mysql_query($query,$koneksi);
	if($execute){
		echo "<script>
				alert('Data Berhasil Di Hapus.');
				location.href='tampil.php';
			</script>";
	}
}
?>
