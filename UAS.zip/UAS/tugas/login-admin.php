<?php
  session_start();
  include("config/koneksi.php");
?>

<html>
    <head>
    <title>Login Admin</title>
<link rel="stylesheet" type="text/css" href="style/adminstyle.css" />
<link href="jquery-ui-1.11.2/jquery-ui.css" rel="stylesheet" />
<script type="text/JavaScript">
    </script>
    </head>
<body>


<div id="loginform">
    <form action="menu/login/index.php" method="post">
	  <span>::Login Admin::</span>
	   <br>
	    <span>Username</span>
        <input type="text" name="username" required>
        <br>
	    <span>Password</span>
        <br>
	    <input type="password" name="password" required>
	       <input type="submit" value="Login" name="proseslogin">
	       <input type="reset" value="Cancel" name="prosescancel">
    </form>
          </div>
          <!-- close form login-->		
</body>
</html>
