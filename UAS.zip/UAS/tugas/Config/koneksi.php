<?php
$HOST = "localhost";
$USER = "root";
$PASSWORD = "12345678";
$DATABASE = "dbade";
//Proses Koneksi//
$koneksi = mysql_connect($HOST,$USER,$PASSWORD);
$database = mysql_select_db($DATABASE,$koneksi);
?>
