<?php
include("config/koneksi.php");
if(isset($_GET['act']) && $_GET['act']=="tambah"){//Jika Penambahan
	$NIMadd = mysql_real_escape_string($_POST['Nim']);	
	$NAMAadd = mysql_real_escape_string($_POST['Nama']);
	$ALAMATadd = mysql_real_escape_string($_POST['Alamat']);
	$KOTAadd = mysql_real_escape_string($_POST['Kota']);
	$PHONEadd = mysql_real_escape_string($_POST['Phone']);
	
	$query = "insert into tblmhs
				(Nim, Nama, Alamat, Kota, Phone)
			values
				('".$NIMadd."', '".$NAMAadd."','".$ALAMATadd."', '".$KOTAadd."','".$PHONEadd."')";
	$execute = mysql_query($query,$koneksi);
	if($execute){
		echo "<script>
				alert('Data Berhasil Di Tambah.');
			location.href='index.php?menu=mahasiswa';
		</script>";
	}
}
?>
