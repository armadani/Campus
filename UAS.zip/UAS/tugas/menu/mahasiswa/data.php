<?php
	$query = "select * from tblmhs";
	$execute = mysql_query($query,$koneksi);
	if(mysql_num_rows($execute)>0){
		echo "<table class=\"data\">
				<tr>
					<th>No.</th>
					<th>NIM</th>
					<th>Nama</th>
					<th>Alamat</th>
					<th>Kota</th>
					<th>Phone</th>
					<th>Action</th>
				</tr>";
		$I = 1;
		while($row = mysql_fetch_array($execute)){
			$ID = $row['Id'];
			$NIM = $row['Nim'];
			$NAMA = $row['Nama'];
			$ALAMAT = $row['Alamat'];
			$KOTA = $row['Kota'];
			$PHONE = $row['Phone'];
			
			echo "<tr>
					<td>".$I."</td>
					<td>".$NIM."</td>
					<td>".$NAMA."</td>
					<td>".$ALAMAT."</td>
					<td>".$KOTA."</td>
					<td>".$PHONE."</td>
					<td>Edit | Delete</td>
				</tr>";
			$I++;
		}
		echo "</table>";
	}else{
		echo "Data Kosong";
	}
?>
