<?php
	include("param.php");
?>


<form action="index.php?menu=mahasiswa&amp;act=tambah" method="post">
    	<table bgcolor="#0066FF">
        	<tr>
                <td>NIM</td>
                <td>:</td>
                <td><input type="text" name="nim" required size="10"></td>
            </tr>

            <tr>
                <td>Nama</td>
                <td>:</td>
                <td><input type="text" name="nama" required size="30"></td>
            </tr>

            <tr>    
                <td>Alamat</td>
                <td>:</td>
                <td><textarea type="text" name="alamat" required></textarea></td>
            </tr>

            <tr>
                <td>Kota</td>
                <td>:</td>
                <td><input type="text" name="kota" required></td>
            </tr>

            <tr>
                <td>Phone</td>
                <td>:</td>
                <td><input type="password" name="phone" required></td>
            </tr>

            <tr>
                <td colspan="3"><input type="submit" value="Proses" name="tambah"></td>
            </tr>
        </table>
    </form>
<?php
	include("data.php");
?>
</div>