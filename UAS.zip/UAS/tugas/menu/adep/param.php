<?php
include("config/koneksi.php");
if(isset($_GET['act']) && $_GET['act']=="tambah"){//Jika Penambahan
	$NABARadd = mysql_real_escape_string($_POST['Nabar']);	
	$JUMLAHadd = mysql_real_escape_string($_POST['Jumlah']);
	$WARNAadd = mysql_real_escape_string($_POST['Warna']);
	$MERKadd = mysql_real_escape_string($_POST['Merk']);
	
	
	$query = "insert into tblbarang
				(Nabar, Jumlah, Warna, Merk )
			values
				('".$Nabaradd."', '".$Jumlahadd."','".$Warnaadd."', '".$Merkadd."')";
	$execute = mysql_query($query,$koneksi);
	if($execute){
		echo "<script>
				alert('Data Berhasil Di Tambah.');
			location.href='index.php?menu=adep';
		</script>";
	}
}
?>
