<?php
	include("param.php");
?>


<form action="index.php?menu=adep&amp;act=tambah" method="post">
    	
    </form>
<?php
	include("data.php");
?>
</div>