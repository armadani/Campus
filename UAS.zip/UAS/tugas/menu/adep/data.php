<?php
	$query = "select * from tblbarang";
	$execute = mysql_query($query,$koneksi);
	if(mysql_num_rows($execute)>0){
		echo "<table class=\"data\">
				<tr>
					<th>Id.</th>
					<th>Nama Barang</th>
					<th>Jumlah Barang</th>
					<th>Warna Barang</th>
					<th>Merk Barang</th>
					
				</tr>";
		$I = 1;
		while($row = mysql_fetch_array($execute)){
			$ID = $row['Id'];
			$NABAR = $row['Nabar'];
			$JUMLAH = $row['Jumlah'];
			$WARNA = $row['Warna'];
			$MERK = $row['Merk'];
			
			echo "<tr>
					<td>".$I."</td>
					<td>".$NABAR."</td>
					<td>".$JUMLAH."</td>
					<td>".$WARNA."</td>
					<td>".$MERK."</td>
				</tr>";
			$I++;
		}
		echo "</table>";
	}else{
		echo "Data Kosong";
	}
?>
