<?php
	$query = "select * from tbldosen";
	$execute = mysql_query($query,$koneksi);
	if(mysql_num_rows($execute)>0){
		echo "<table class=\"data\">
				<tr>
					<th>Nama</th>
					<th>Mata Kuliah</th>
					<th>Alamat</th>
					<th>Phone</th>
				</tr>";
		$I = 1;
		while($row = mysql_fetch_array($execute)){
			$NAMA = $row['Nama'];
			$MATKUL = $row['Matkul'];
			$ALAMAT = $row['Alamat'];
			$PHONE = $row['Phone'];
			
			echo "<tr>
					<td>".$NAMA."</td>
					<td>".$MATKUL."</td>
					<td>".$ALAMAT."</td>
					<td>".$PHONE."</td>
				</tr>";
			$I++;
		}
		echo "</table>";
	}else{
		echo "Data Kosong";
	}
?>
