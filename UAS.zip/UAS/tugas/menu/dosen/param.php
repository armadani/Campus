<?php
include("config/koneksi.php");
if(isset($_GET['act']) && $_GET['act']=="tambah"){//Jika Penambahan
	$NAMAadd = mysql_real_escape_string($_POST['Nama']);
    $MATKULadd = mysql_real_escape_string($_POST['Matkul']);
	$ALAMATadd = mysql_real_escape_string($_POST['Alamat']);
	$PHONEadd = mysql_real_escape_string($_POST['Phone']);
	
	$query = "insert into tbldosen
				(Nama, Matkul, Alamat, Phone)
			values
				('".$NAMAadd."', '".$MATKULadd."', '".$ALAMATadd."', '".$PHONEadd."')";
	$execute = mysql_query($query,$koneksi);
	if($execute){
		echo "<script>
				alert('Data Berhasil Di Tambah.');
			location.href='index.php?menu=dosen';
		</script>";
	}
}
?>
