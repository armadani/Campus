<?php
include("config/koneksi.php");
if(isset($_GET['act']) && $_GET['act']=="tambah"){//Jika Penambahan
	$NIMadd = mysql_real_escape_string($_POST['Nim']);	
	$MKadd = mysql_real_escape_string($_POST['MK']);
	$DOSENadd = mysql_real_escape_string($_POST['Dosen']);
	$NILAIadd = mysql_real_escape_string($_POST['Nilai']);
	
	
	$query = "insert into tblnilai
				(Nim, MK, Dosen, Nilai)
			values
				('".$NIMadd."', '".$MKadd."','".$DOSENadd."', '".$NILAIadd."')";
	$execute = mysql_query($query,$koneksi);
	if($execute){
		echo "<script>
				alert('Data Berhasil Di Tambah.');
			location.href='index.php?menu=nilai';
		</script>";
	}
}
?>
