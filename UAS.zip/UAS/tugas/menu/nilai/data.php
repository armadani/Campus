<?php
	$query = "select * from tblnilai";
	$execute = mysql_query($query,$koneksi);
	if(mysql_num_rows($execute)>0){
		echo "<table class=\"data\">
				<tr>
					<th>No.</th>
					<th>NIM</th>
					<th>MK</th>
					<th>Dosen</th>
					<th>Nilai</th>
					<th>Action</th>
				</tr>";
		$I = 1;
		while($row = mysql_fetch_array($execute)){
			$ID = $row['Id'];
			$NIM = $row['Nim'];
			$MK = $row['Mk'];
			$DOSEN = $row['Dosen'];
			$NILAI = $row['Nilai'];
			
			echo "<tr>
					<td>".$I."</td>
					<td>".$NIM."</td>
					<td>".$MK."</td>
					<td>".$DOSEN."</td>
					<td>".$NILAI."</td>
					<td>Edit | Delete</td>
				</tr>";
			$I++;
		}
		echo "</table>";
	}else{
		echo "Data Kosong";
	}
?>
