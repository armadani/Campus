<?php
	if(isset($_GET['menu']) && $_GET['menu'] == "mahasiswa"){
		include("menu/mahasiswa/index.php");
	}elseif(isset($_GET['menu']) && $_GET['menu'] == "nilai"){
		include("menu/nilai/index.php");
	}elseif(isset($_GET['menu']) && $_GET['menu'] == "dosen"){
		include("menu/dosen/index.php");
		}elseif(isset($_GET['menu']) && $_GET['menu'] == "adep"){
		include("menu/adep/index.php");
		
	}elseif($_GET['menu'] == ""){
		include("menu/index.php");
	}
?>
